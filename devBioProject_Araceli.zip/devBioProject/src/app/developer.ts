export class Developer {
    constructor(public id:number,
                public firstName:string,
                public lastName:string, 
                public favouriteLanguage:string, 
                public yearStarted:number) {

    }
}
