import { Injectable } from '@angular/core';
import { Developer } from './developer';

@Injectable({
  providedIn: 'root'
})
export class DeveloperService {

  constructor() { 
    this.loadDevelopers();
  }

  devs!: Developer[];

  private loadDevelopers()  {
    this.devs = [new Developer(1, "Araceli","Teixeira","Java/Javascript", 2009),
      new Developer(2, "Tarryn","Ernd","C++", 1997)
    ];
  }

  public getAllDevelopers() : Developer[] {
    return this.devs;
  }

  public getDeveloperById(x:number) : Developer {
    let dev = this.devs.find(dev => dev.id == x);
    return dev == null ? new Developer(0, "", "", "", 0) : dev;
  }
}
